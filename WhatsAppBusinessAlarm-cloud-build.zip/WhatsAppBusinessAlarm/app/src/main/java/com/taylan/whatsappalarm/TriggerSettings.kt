package com.taylan.whatsappalarm

import android.content.Context

object TriggerSettings {
    private const val PREFS_NAME = "alarm_settings"
    private const val KEY_TRIGGER = "trigger_text"
    const val DEFAULT_TRIGGER = "Gazipaşa"

    fun getTrigger(context: Context): String {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(KEY_TRIGGER, DEFAULT_TRIGGER)
            ?.trim()
            .orEmpty()
            .ifBlank { DEFAULT_TRIGGER }
    }

    fun saveTrigger(context: Context, trigger: String) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_TRIGGER, trigger.trim())
            .apply()
    }
}
