package com.taylan.whatsappalarm

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import java.text.Normalizer
import java.util.Locale

class WhatsAppNotificationListener : NotificationListenerService() {

    companion object {
        private const val WHATSAPP_BUSINESS_PACKAGE = "com.whatsapp.w4b"
        private const val DUPLICATE_WINDOW_MS = 10_000L
        private var lastMatchedText: String? = null
        private var lastMatchedAt: Long = 0L
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName != WHATSAPP_BUSINESS_PACKAGE) return

        val extras = sbn.notification.extras
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        val bigText = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString().orEmpty()
        val lines = extras.getCharSequenceArray(Notification.EXTRA_TEXT_LINES)
            ?.joinToString(" ") { it.toString() }
            .orEmpty()

        val completeText = normalizeForMatch("$title $text $bigText $lines")
        val trigger = normalizeForMatch(TriggerSettings.getTrigger(applicationContext))

        if (trigger.isNotBlank() && completeText.contains(trigger) && !isDuplicate(completeText)) {
            AlarmController.start(applicationContext)
        }
    }

    private fun isDuplicate(text: String): Boolean {
        val now = System.currentTimeMillis()
        val duplicate = text == lastMatchedText && now - lastMatchedAt < DUPLICATE_WINDOW_MS
        if (!duplicate) {
            lastMatchedText = text
            lastMatchedAt = now
        }
        return duplicate
    }

    private fun normalizeForMatch(value: String): String {
        val lower = value.lowercase(Locale("tr", "TR"))
            .replace('ı', 'i')
            .replace('ş', 's')
            .replace('ğ', 'g')
            .replace('ü', 'u')
            .replace('ö', 'o')
            .replace('ç', 'c')

        return Normalizer.normalize(lower, Normalizer.Form.NFD)
            .replace("\\p{Mn}+".toRegex(), "")
            .replace("\\s+".toRegex(), " ")
            .trim()
    }
}
